from softserve.credLoader import CredLoader

credLoader = CredLoader()

credLoader.loadCreds()
