from softserve.softserve import *

__version__ = "12.0.0"
