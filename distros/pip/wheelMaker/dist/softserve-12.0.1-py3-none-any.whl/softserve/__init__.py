#This is the modified version of __init__.py for the standalone version.
#This will temporarily add the deps folder to python's path / list of folders to import modules
#from, allowing the softserve library to function without the user needing to install them


from .Jackbord import Jackbord

__version__ = "12.0.0"
